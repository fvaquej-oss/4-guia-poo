"""Rutas de academico. Cada CRUD sigue el patrón <modelo>_lista, _crear, _detalle, _editar, _eliminar y _pdf."""
from django.urls import path

from . import views

app_name = "academico"


def crud(ruta, modelo, clase):
    """Las 6 rutas de un CRUD. `clase` es el prefijo de las vistas (ej. 'Estudiante' → EstudianteListView)."""
    v = lambda sufijo: getattr(views, f"{clase}{sufijo}View").as_view()
    return [
        path(f"{ruta}/", v("List"), name=f"{modelo}_lista"),
        path(f"{ruta}/crear/", v("Create"), name=f"{modelo}_crear"),
        path(f"{ruta}/<int:pk>/", v("Detail"), name=f"{modelo}_detalle"),
        path(f"{ruta}/<int:pk>/editar/", v("Update"), name=f"{modelo}_editar"),
        path(f"{ruta}/<int:pk>/eliminar/", v("Delete"), name=f"{modelo}_eliminar"),
        path(f"{ruta}/<int:pk>/pdf/", v("Pdf"), name=f"{modelo}_pdf"),
    ]


urlpatterns = [path("", views.InicioView.as_view(), name="inicio")]
urlpatterns += crud("universidades", "universidad", "Universidad")
urlpatterns += crud("facultades", "facultad", "Facultad")
urlpatterns += crud("carreras", "carrera", "Carrera")
urlpatterns += crud("semestres", "semestre", "Semestre")
urlpatterns += crud("periodos", "periodo", "Periodo")
urlpatterns += crud("cursos", "curso", "Curso")
urlpatterns += crud("profesores", "profesor", "Profesor")
urlpatterns += crud("secciones", "seccion", "Seccion")
urlpatterns += crud("estudiantes", "estudiante", "Estudiante")
urlpatterns += crud("matriculas", "matricula", "Matricula")
