"""Crea datos de prueba para el sistema académico. Se puede ejecutar varias veces: no duplica nada.

    python manage.py poblar_datos
"""
from datetime import date
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db import transaction

from academico.models import (Carrera, Curso, Estudiante, Facultad, Matricula, Nota, Periodo, Profesor,
                              Seccion, Semestre, Universidad)


class Command(BaseCommand):
    help = "Crea datos de prueba: universidades, carreras, cursos, secciones, estudiantes, matrículas y notas"

    @transaction.atomic
    def handle(self, *args, **options):
        # --- Estructura: 2 universidades, 3 facultades, 3 carreras ---
        ug, _ = Universidad.objects.get_or_create(
            nombre="Universidad de Guayaquil", defaults={"siglas": "UG", "ciudad": "Guayaquil"})
        espol, _ = Universidad.objects.get_or_create(
            nombre="Escuela Politécnica del Litoral", defaults={"siglas": "ESPOL", "ciudad": "Guayaquil"})

        fac_mat, _ = Facultad.objects.get_or_create(
            universidad=ug, nombre="Ciencias Matemáticas y Físicas", defaults={"decano": "Dr. Jorge Alvarado"})
        fac_ind, _ = Facultad.objects.get_or_create(
            universidad=ug, nombre="Ingeniería Industrial", defaults={"decano": "Ing. Rosa Cedeño"})
        Facultad.objects.get_or_create(
            universidad=espol, nombre="Ing. Electricidad y Computación", defaults={"decano": "Dr. Luis Barzola"})

        sof, _ = Carrera.objects.get_or_create(codigo="SOF", defaults={
            "facultad": fac_mat, "nombre": "Software", "duracion_semestres": 8})
        red, _ = Carrera.objects.get_or_create(codigo="RED", defaults={
            "facultad": fac_mat, "nombre": "Redes y Telecomunicaciones", "duracion_semestres": 8})
        ind, _ = Carrera.objects.get_or_create(codigo="IND", defaults={
            "facultad": fac_ind, "nombre": "Ingeniería Industrial", "duracion_semestres": 10})

        # --- Catálogo: 2 semestres, 1 periodo activo, 6 cursos ---
        sem1, _ = Semestre.objects.get_or_create(numero=1, defaults={"nombre": "Primer semestre"})
        sem2, _ = Semestre.objects.get_or_create(numero=2, defaults={"nombre": "Segundo semestre"})
        periodo, _ = Periodo.objects.get_or_create(nombre="2026-1", defaults={
            "fecha_inicio": date(2026, 4, 1), "fecha_fin": date(2026, 8, 31), "activo": True})

        cursos = {}
        for carrera, semestre, codigo, nombre, creditos in [
            (sof, sem1, "SOF-101", "Programación I", 4),
            (sof, sem1, "SOF-102", "Matemática discreta", 3),
            (sof, sem2, "SOF-201", "Programación II", 4),
            (red, sem1, "RED-101", "Fundamentos de redes", 4),
            (red, sem2, "RED-201", "Enrutamiento y conmutación", 4),
            (ind, sem1, "IND-101", "Introducción a la ingeniería industrial", 3),
        ]:
            cursos[codigo], _ = Curso.objects.get_or_create(codigo=codigo, defaults={
                "carrera": carrera, "semestre": semestre, "nombre": nombre, "creditos": creditos})

        # --- Personas: 3 profesores ---
        vera, _ = Profesor.objects.get_or_create(cedula="0911111111", defaults={
            "apellidos": "Vera", "nombres": "Carlos", "email": "cvera@ejemplo.edu.ec", "titulo": "Mg. en Software"})
        leon, _ = Profesor.objects.get_or_create(cedula="0922222222", defaults={
            "apellidos": "León", "nombres": "María", "email": "mleon@ejemplo.edu.ec", "titulo": "Mg. en Educación"})
        mora, _ = Profesor.objects.get_or_create(cedula="0933333333", defaults={
            "apellidos": "Mora", "nombres": "Pedro", "email": "pmora@ejemplo.edu.ec", "titulo": "Ing. en Telecomunicaciones"})

        # --- Oferta: 4 secciones (diurnas y nocturnas) ---
        sec = {}
        for clave, codigo, prof, paralelo, jornada, cupo in [
            ("sof101a", "SOF-101", vera, "A", "diurna", 30),
            ("sof101b", "SOF-101", leon, "B", "nocturna", 25),
            ("sof102a", "SOF-102", vera, "A", "diurna", 30),
            ("red101a", "RED-101", mora, "A", "diurna", 30),
        ]:
            sec[clave], _ = Seccion.objects.get_or_create(
                curso=cursos[codigo], periodo=periodo, paralelo=paralelo, jornada=jornada,
                defaults={"profesor": prof, "cupo": cupo})

        # --- 15 estudiantes: 10 de Software y 5 de Redes ---
        nombres = [
            ("0912345678", "Pérez", "Ana", sof), ("0999999999", "Mora", "Luis", sof),
            ("0988888888", "Ruiz", "Eva", sof), ("0901010101", "Castro", "Diego", sof),
            ("0902020202", "Zambrano", "Paula", sof), ("0903030303", "Intriago", "Mateo", sof),
            ("0904040404", "Vélez", "Camila", sof), ("0905050505", "Macías", "Andrés", sof),
            ("0906060606", "Salazar", "Daniela", sof), ("0907070707", "Burgos", "Kevin", sof),
            ("0908080808", "Cevallos", "Lucía", red), ("0909090909", "Torres", "Jorge", red),
            ("0910101010", "Villamar", "Sofía", red), ("0913131313", "Ponce", "Ricardo", red),
            ("0914141414", "Franco", "Valeria", red),
        ]
        estudiantes = []
        for cedula, apellidos, nombre, carrera in nombres:
            est, _ = Estudiante.objects.get_or_create(cedula=cedula, defaults={
                "apellidos": apellidos, "nombres": nombre, "carrera": carrera,
                "email": f"{nombre.lower()}.{apellidos.lower().replace('é', 'e').replace('í', 'i')}@ejemplo.edu.ec",
                "telefono": "09" + cedula[2:10]})
            estudiantes.append(est)
        soft = [e for e in estudiantes if e.carrera_id == sof.pk]
        redes = [e for e in estudiantes if e.carrera_id == red.pk]

        # --- 25 matrículas: 10 en Prog I (A o B), 10 en Mat. discreta, 5 en Fundamentos de redes ---
        pares = []
        for i, e in enumerate(soft):
            pares.append((e, sec["sof101a"] if i % 2 == 0 else sec["sof101b"]))
            pares.append((e, sec["sof102a"]))
        pares += [(e, sec["red101a"]) for e in redes]

        # --- Notas variadas (algunas aprobadas y otras reprobadas); las 2 últimas matrículas quedan sin nota ---
        notas = [(80, 65, 66), (90, 85, 88), (60, 70, 55), (75, 80, 72), (95, 90, 100), (40, 55, 50),
                 (70, 70, 70), (85, 60, 78), (30, 45, 52), (88, 92, 79), (65, 68, 60), (100, 95, 98)]
        creadas = 0
        for i, (est, seccion) in enumerate(pares):
            matricula, nueva = Matricula.objects.get_or_create(
                estudiante=est, seccion=seccion, defaults={"fecha": date(2026, 3, 20)})
            creadas += nueva
            if i >= len(pares) - 2:
                continue
            n1, n2, n3 = notas[i % len(notas)]
            Nota.objects.get_or_create(matricula=matricula, defaults={"n1": Decimal(n1), "n2": Decimal(n2), "n3": Decimal(n3)})  # create() llama a save()

        self.stdout.write(self.style.SUCCESS(
            f"Datos listos: {Universidad.objects.count()} universidades, {Estudiante.objects.count()} estudiantes, "
            f"{Seccion.objects.count()} secciones, {Matricula.objects.count()} matrículas, {Nota.objects.count()} notas."))
