# =====================================================================
# academico/views.py · 10 CRUD con vistas BASADAS EN CLASES.
# Cada CRUD solo CONFIGURA los componentes de core (filtros, Excel, PDF, comprobante).
# =====================================================================
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import transaction
from django.db.models import Q
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.views.generic import CreateView, TemplateView, UpdateView

from core.mixins import CrudContextoMixin
from core.views import (ComprobanteBase, CrearBase, DetalleBase, EditarBase, EliminarBase, ListadoBase)

from . import forms
from .models import (Carrera, Curso, Estudiante, EstadoNota, Facultad, Matricula, Nota, Periodo,
                     Profesor, Seccion, Semestre, Universidad)


# =====================================================================
# INICIO
# =====================================================================
class InicioView(LoginRequiredMixin, TemplateView):
    template_name = "academico/inicio.html"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        periodo = Periodo.objects.filter(activo=True).first()
        total_notas = Nota.objects.count()
        aprobados = Nota.objects.filter(estado=EstadoNota.APROBADO).count()
        contexto.update({
            "periodo_activo": periodo,
            "total_estudiantes": Estudiante.objects.count(),
            "secciones_periodo": Seccion.objects.filter(periodo__activo=True).count(),
            "total_matriculas": Matricula.objects.count(),
            "porcentaje_aprobados": round(aprobados * 100 / total_notas, 1) if total_notas else 0,   # evita dividir entre 0
            "aprobados_periodo": Nota.objects.filter(matricula__seccion__periodo__activo=True,
                                                     estado=EstadoNota.APROBADO).count(),
            "reprobados_periodo": Nota.objects.filter(matricula__seccion__periodo__activo=True,
                                                      estado=EstadoNota.REPROBADO).count(),
        })
        return contexto


# =====================================================================
# 1. UNIVERSIDAD
# =====================================================================
class UniversidadListView(ListadoBase):
    model = Universidad
    filtro_form_class = forms.FiltroUniversidadForm
    campos_disponibles = [("siglas", "Siglas"), ("nombre", "Nombre"), ("ciudad", "Ciudad"),
                          ("total_facultades", "N.º de facultades")]
    campos_por_defecto = ["siglas", "nombre", "ciudad", "total_facultades"]
    titulo_reporte = "Listado de universidades"
    nombre_archivo = "universidades"

    def filtrar(self, queryset, datos):
        if datos.get("texto"):
            queryset = queryset.filter(Q(nombre__icontains=datos["texto"]) | Q(siglas__icontains=datos["texto"]))
        if datos.get("ciudad"):
            queryset = queryset.filter(ciudad__icontains=datos["ciudad"])
        return queryset


class UniversidadCreateView(CrearBase):
    model = Universidad
    form_class = forms.UniversidadForm


class UniversidadUpdateView(EditarBase):
    model = Universidad
    form_class = forms.UniversidadForm


class UniversidadDetailView(DetalleBase):
    model = Universidad
    detalle_campos = [("nombre", "Nombre"), ("siglas", "Siglas"), ("ciudad", "Ciudad"),
                      ("total_facultades", "N.º de facultades")]
    relaciones = [("Facultades", "facultades", [("nombre", "Facultad"), ("decano", "Decano")])]


class UniversidadDeleteView(EliminarBase):
    model = Universidad
    mensaje_protegido = "No se puede eliminar: tiene facultades."


class UniversidadPdfView(ComprobanteBase):
    model = Universidad
    template_pdf = "academico/pdf/universidad_ficha.html"
    nombre_archivo = "universidad"

    def obtener_universidad(self):
        return self.object


# =====================================================================
# 2. FACULTAD
# =====================================================================
class FacultadListView(ListadoBase):
    model = Facultad
    queryset = Facultad.objects.select_related("universidad")
    filtro_form_class = forms.FiltroFacultadForm
    campos_disponibles = [("universidad__siglas", "Universidad"), ("nombre", "Facultad"), ("decano", "Decano")]
    campos_por_defecto = ["universidad__siglas", "nombre", "decano"]
    titulo_reporte = "Listado de facultades"
    nombre_archivo = "facultades"

    def filtrar(self, queryset, datos):
        if datos.get("universidad"):
            queryset = queryset.filter(universidad=datos["universidad"])
        if datos.get("texto"):
            queryset = queryset.filter(Q(nombre__icontains=datos["texto"]) | Q(decano__icontains=datos["texto"]))
        return queryset


class FacultadCreateView(CrearBase):
    model = Facultad
    form_class = forms.FacultadForm


class FacultadUpdateView(EditarBase):
    model = Facultad
    form_class = forms.FacultadForm


class FacultadDetailView(DetalleBase):
    model = Facultad
    detalle_campos = [("universidad", "Universidad"), ("nombre", "Nombre"), ("decano", "Decano")]
    relaciones = [("Carreras", "carreras", [("codigo", "Código"), ("nombre", "Carrera"),
                                            ("duracion_semestres", "Duración (semestres)")])]


class FacultadDeleteView(EliminarBase):
    model = Facultad
    mensaje_protegido = "No se puede eliminar: tiene carreras."


class FacultadPdfView(ComprobanteBase):
    model = Facultad
    template_pdf = "academico/pdf/facultad_ficha.html"
    nombre_archivo = "facultad"

    def obtener_universidad(self):
        return self.object.universidad


# =====================================================================
# 3. CARRERA
# =====================================================================
class CarreraListView(ListadoBase):
    model = Carrera
    queryset = Carrera.objects.select_related("facultad__universidad")
    filtro_form_class = forms.FiltroCarreraForm
    campos_disponibles = [("codigo", "Código"), ("nombre", "Carrera"), ("facultad__nombre", "Facultad"),
                          ("facultad__universidad__siglas", "Universidad"),
                          ("duracion_semestres", "Duración (semestres)")]
    campos_por_defecto = ["codigo", "nombre", "facultad__nombre", "duracion_semestres"]
    titulo_reporte = "Listado de carreras"
    nombre_archivo = "carreras"

    def filtrar(self, queryset, datos):
        if datos.get("universidad"):
            queryset = queryset.filter(facultad__universidad=datos["universidad"])
        if datos.get("facultad"):
            queryset = queryset.filter(facultad=datos["facultad"])
        if datos.get("texto"):
            queryset = queryset.filter(Q(codigo__icontains=datos["texto"]) | Q(nombre__icontains=datos["texto"]))
        return queryset


class CarreraCreateView(CrearBase):
    model = Carrera
    form_class = forms.CarreraForm


class CarreraUpdateView(EditarBase):
    model = Carrera
    form_class = forms.CarreraForm


class CarreraDetailView(DetalleBase):
    model = Carrera
    detalle_campos = [("codigo", "Código"), ("nombre", "Nombre"), ("facultad", "Facultad"),
                      ("facultad__universidad", "Universidad"), ("duracion_semestres", "Duración (semestres)")]
    relaciones = [("Cursos", "cursos", [("codigo", "Código"), ("nombre", "Curso"), ("semestre", "Semestre"),
                                        ("creditos", "Créditos")])]


class CarreraDeleteView(EliminarBase):
    model = Carrera
    mensaje_protegido = "No se puede eliminar: tiene cursos o estudiantes."


class CarreraPdfView(ComprobanteBase):
    """Malla curricular: los cursos de la carrera agrupados por semestre."""
    model = Carrera
    template_pdf = "academico/pdf/carrera_malla.html"
    nombre_archivo = "malla"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["cursos"] = self.object.cursos.select_related("semestre").order_by("semestre__numero", "nombre")
        return contexto

    def obtener_universidad(self):
        return self.object.facultad.universidad


# =====================================================================
# 4. SEMESTRE
# =====================================================================
class SemestreListView(ListadoBase):
    model = Semestre
    filtro_form_class = forms.FiltroSemestreForm
    campos_disponibles = [("numero", "Número"), ("nombre", "Nombre")]
    campos_por_defecto = ["numero", "nombre"]
    titulo_reporte = "Listado de semestres"
    nombre_archivo = "semestres"

    def filtrar(self, queryset, datos):
        if datos.get("texto"):
            queryset = queryset.filter(Q(nombre__icontains=datos["texto"]) | Q(numero__icontains=datos["texto"]))
        return queryset


class SemestreCreateView(CrearBase):
    model = Semestre
    form_class = forms.SemestreForm


class SemestreUpdateView(EditarBase):
    model = Semestre
    form_class = forms.SemestreForm


class SemestreDetailView(DetalleBase):
    model = Semestre
    detalle_campos = [("numero", "Número"), ("nombre", "Nombre")]
    relaciones = [("Cursos", "cursos", [("codigo", "Código"), ("nombre", "Curso"),
                                        ("carrera__nombre", "Carrera"), ("creditos", "Créditos")])]


class SemestreDeleteView(EliminarBase):
    model = Semestre
    mensaje_protegido = "No se puede eliminar: tiene cursos."


class SemestrePdfView(ComprobanteBase):
    model = Semestre
    template_pdf = "academico/pdf/semestre_ficha.html"
    nombre_archivo = "semestre"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["cursos"] = self.object.cursos.select_related("carrera")
        return contexto


# =====================================================================
# 5. PERIODO (solo uno activo)
# =====================================================================
class PeriodoListView(ListadoBase):
    model = Periodo
    filtro_form_class = forms.FiltroPeriodoForm
    campos_disponibles = [("nombre", "Periodo"), ("fecha_inicio", "Inicio"), ("fecha_fin", "Fin"),
                          ("activo", "Activo")]
    campos_por_defecto = ["nombre", "fecha_inicio", "fecha_fin", "activo"]
    titulo_reporte = "Listado de periodos"
    nombre_archivo = "periodos"

    def filtrar(self, queryset, datos):
        if datos.get("activo"):
            queryset = queryset.filter(activo=datos["activo"] == "1")
        if datos.get("anio"):
            queryset = queryset.filter(fecha_inicio__year=datos["anio"])
        return queryset


class _UnSoloActivoMixin:
    def form_valid(self, form):
        if form.cleaned_data["activo"]:
            Periodo.objects.exclude(pk=form.instance.pk).update(activo=False)    # apaga los demás
        return super().form_valid(form)


class PeriodoCreateView(_UnSoloActivoMixin, CrearBase):
    model = Periodo
    form_class = forms.PeriodoForm


class PeriodoUpdateView(_UnSoloActivoMixin, EditarBase):
    model = Periodo
    form_class = forms.PeriodoForm


class PeriodoDetailView(DetalleBase):
    model = Periodo
    detalle_campos = [("nombre", "Periodo"), ("fecha_inicio", "Inicio"), ("fecha_fin", "Fin"), ("activo", "Activo")]
    relaciones = [("Secciones", "secciones", [("curso", "Curso"), ("paralelo", "Paralelo"), ("jornada", "Jornada"),
                                              ("profesor", "Profesor"), ("inscritos", "Inscritos")])]


class PeriodoDeleteView(EliminarBase):
    model = Periodo
    mensaje_protegido = "No se puede eliminar: tiene secciones."


class PeriodoPdfView(ComprobanteBase):
    """Resumen del periodo: sus secciones y cuántos estudiantes tiene cada una."""
    model = Periodo
    template_pdf = "academico/pdf/periodo_resumen.html"
    nombre_archivo = "periodo"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        secciones = self.object.secciones.select_related("curso", "profesor")
        contexto["secciones"] = secciones
        contexto["total_secciones"] = secciones.count()
        contexto["total_inscritos"] = Matricula.objects.filter(seccion__periodo=self.object).count()
        return contexto


# =====================================================================
# 6. CURSO
# =====================================================================
class CursoListView(ListadoBase):
    model = Curso
    queryset = Curso.objects.select_related("carrera", "semestre")
    filtro_form_class = forms.FiltroCursoForm
    campos_disponibles = [("codigo", "Código"), ("nombre", "Curso"), ("carrera__nombre", "Carrera"),
                          ("semestre", "Semestre"), ("creditos", "Créditos")]
    campos_por_defecto = ["codigo", "nombre", "carrera__nombre", "semestre", "creditos"]
    titulo_reporte = "Listado de cursos"
    nombre_archivo = "cursos"

    def filtrar(self, queryset, datos):
        if datos.get("carrera"):
            queryset = queryset.filter(carrera=datos["carrera"])
        if datos.get("semestre"):
            queryset = queryset.filter(semestre=datos["semestre"])
        if datos.get("texto"):
            queryset = queryset.filter(Q(codigo__icontains=datos["texto"]) | Q(nombre__icontains=datos["texto"]))
        return queryset


class CursoCreateView(CrearBase):
    model = Curso
    form_class = forms.CursoForm


class CursoUpdateView(EditarBase):
    model = Curso
    form_class = forms.CursoForm


class CursoDetailView(DetalleBase):
    model = Curso
    detalle_campos = [("codigo", "Código"), ("nombre", "Nombre"), ("carrera", "Carrera"),
                      ("semestre", "Semestre"), ("creditos", "Créditos")]
    relaciones = [("Secciones", "secciones", [("periodo__nombre", "Periodo"), ("paralelo", "Paralelo"),
                                              ("jornada", "Jornada"), ("profesor", "Profesor"),
                                              ("inscritos", "Inscritos")])]


class CursoDeleteView(EliminarBase):
    model = Curso
    mensaje_protegido = "No se puede eliminar: tiene secciones."


class CursoPdfView(ComprobanteBase):
    model = Curso
    template_pdf = "academico/pdf/curso_ficha.html"
    nombre_archivo = "curso"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["secciones"] = self.object.secciones.select_related("periodo", "profesor")
        return contexto

    def obtener_universidad(self):
        return self.object.carrera.facultad.universidad


# =====================================================================
# 7. PROFESOR
# =====================================================================
class ProfesorListView(ListadoBase):
    model = Profesor
    filtro_form_class = forms.FiltroProfesorForm
    campos_disponibles = [("cedula", "Cédula"), ("apellidos", "Apellidos"), ("nombres", "Nombres"),
                          ("titulo", "Título"), ("email", "Correo")]
    campos_por_defecto = ["cedula", "apellidos", "nombres", "titulo"]
    titulo_reporte = "Listado de profesores"
    nombre_archivo = "profesores"

    def filtrar(self, queryset, datos):
        if datos.get("texto"):
            t = datos["texto"]
            queryset = queryset.filter(Q(cedula__icontains=t) | Q(apellidos__icontains=t) | Q(nombres__icontains=t))
        if datos.get("periodo"):
            queryset = queryset.filter(secciones__periodo=datos["periodo"]).distinct()   # sin repetidos
        return queryset


class ProfesorCreateView(CrearBase):
    model = Profesor
    form_class = forms.ProfesorForm


class ProfesorUpdateView(EditarBase):
    model = Profesor
    form_class = forms.ProfesorForm


class ProfesorDetailView(DetalleBase):
    model = Profesor
    detalle_campos = [("cedula", "Cédula"), ("apellidos", "Apellidos"), ("nombres", "Nombres"),
                      ("email", "Correo"), ("titulo", "Título")]
    relaciones = [("Secciones que dicta", "secciones", [("periodo__nombre", "Periodo"), ("curso", "Curso"),
                                                       ("paralelo", "Paralelo"), ("jornada", "Jornada"),
                                                       ("inscritos", "Inscritos")])]


class ProfesorDeleteView(EliminarBase):
    model = Profesor
    mensaje_protegido = "No se puede eliminar: tiene secciones asignadas."


class ProfesorPdfView(ComprobanteBase):
    """Carga académica: las secciones del profesor en el periodo activo."""
    model = Profesor
    template_pdf = "academico/pdf/profesor_carga.html"
    nombre_archivo = "carga-academica"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["periodo"] = Periodo.objects.filter(activo=True).first()
        contexto["secciones"] = (self.object.secciones.filter(periodo__activo=True)
                                 .select_related("curso", "periodo"))
        return contexto


# =====================================================================
# 8. SECCIÓN
# =====================================================================
class SeccionListView(ListadoBase):
    model = Seccion
    queryset = Seccion.objects.select_related("curso__carrera", "periodo", "profesor")
    filtro_form_class = forms.FiltroSeccionForm
    campos_disponibles = [("curso", "Curso"), ("periodo__nombre", "Periodo"), ("paralelo", "Paralelo"),
                          ("jornada", "Jornada"), ("profesor", "Profesor"), ("cupo", "Cupo"),
                          ("inscritos", "Inscritos")]
    campos_por_defecto = ["curso", "periodo__nombre", "paralelo", "jornada", "profesor", "cupo", "inscritos"]
    titulo_reporte = "Listado de secciones"
    nombre_archivo = "secciones"

    def filtrar(self, queryset, datos):
        if datos.get("periodo"):
            queryset = queryset.filter(periodo=datos["periodo"])
        if datos.get("carrera"):
            queryset = queryset.filter(curso__carrera=datos["carrera"])
        if datos.get("jornada"):
            queryset = queryset.filter(jornada=datos["jornada"])
        if datos.get("profesor"):
            queryset = queryset.filter(profesor=datos["profesor"])
        return queryset


class SeccionCreateView(CrearBase):
    model = Seccion
    form_class = forms.SeccionForm


class SeccionUpdateView(EditarBase):
    model = Seccion
    form_class = forms.SeccionForm


class SeccionDetailView(DetalleBase):
    model = Seccion
    detalle_campos = [("curso", "Curso"), ("periodo", "Periodo"), ("profesor", "Profesor"),
                      ("paralelo", "Paralelo"), ("jornada", "Jornada"), ("cupo", "Cupo"),
                      ("inscritos", "Inscritos")]
    relaciones = [("Estudiantes matriculados", "matriculas",
                   [("estudiante__cedula", "Cédula"), ("estudiante", "Estudiante"),
                    ("nota__promedio", "Promedio"), ("nota__estado", "Estado")])]


class SeccionDeleteView(EliminarBase):
    model = Seccion
    mensaje_protegido = "No se puede eliminar: tiene matrículas."


class SeccionPdfView(ComprobanteBase):
    """Acta de calificaciones de la sección."""
    model = Seccion
    template_pdf = "academico/pdf/seccion_acta.html"
    nombre_archivo = "acta"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["matriculas"] = (self.object.matriculas.select_related("estudiante", "nota")
                                  .order_by("estudiante__apellidos", "estudiante__nombres"))
        return contexto

    def obtener_universidad(self):
        return self.object.curso.carrera.facultad.universidad


# =====================================================================
# 9. ESTUDIANTE
# =====================================================================
class EstudianteListView(ListadoBase):
    model = Estudiante
    queryset = Estudiante.objects.select_related("carrera__facultad")
    filtro_form_class = forms.FiltroEstudianteForm
    campos_disponibles = [("cedula", "Cédula"), ("apellidos", "Apellidos"), ("nombres", "Nombres"),
                          ("email", "Correo"), ("telefono", "Teléfono"), ("fecha_nacimiento", "Nacimiento"),
                          ("carrera__nombre", "Carrera"), ("carrera__facultad__nombre", "Facultad")]
    campos_por_defecto = ["cedula", "apellidos", "nombres", "carrera__nombre"]
    titulo_reporte = "Listado de estudiantes"
    nombre_archivo = "estudiantes"

    def filtrar(self, queryset, datos):
        if datos.get("texto"):
            t = datos["texto"]
            queryset = queryset.filter(Q(nombres__icontains=t) | Q(apellidos__icontains=t) | Q(cedula__icontains=t))
        if datos.get("carrera"):
            queryset = queryset.filter(carrera=datos["carrera"])
        if datos.get("facultad"):
            queryset = queryset.filter(carrera__facultad=datos["facultad"])
        if datos.get("nacido_desde"):
            queryset = queryset.filter(fecha_nacimiento__gte=datos["nacido_desde"])
        if datos.get("nacido_hasta"):
            queryset = queryset.filter(fecha_nacimiento__lte=datos["nacido_hasta"])
        return queryset


class EstudianteCreateView(CrearBase):
    model = Estudiante
    form_class = forms.EstudianteForm


class EstudianteUpdateView(EditarBase):
    model = Estudiante
    form_class = forms.EstudianteForm


class EstudianteDetailView(DetalleBase):
    model = Estudiante
    template_name = "academico/estudiante_detalle.html"              # igual que el genérico, pero con la foto
    detalle_campos = [("cedula", "Cédula"), ("nombres", "Nombres"), ("apellidos", "Apellidos"),
                      ("email", "Correo"), ("telefono", "Teléfono"), ("fecha_nacimiento", "Nacimiento"),
                      ("carrera", "Carrera"), ("carrera__facultad", "Facultad")]
    relaciones = [("Matrículas y notas", "matriculas",
                   [("seccion__periodo__nombre", "Periodo"), ("seccion__curso", "Curso"),
                    ("seccion__jornada", "Jornada"), ("nota__promedio", "Promedio"), ("nota__estado", "Estado")])]


class EstudianteDeleteView(EliminarBase):
    model = Estudiante
    mensaje_protegido = "No se puede eliminar: tiene matrículas."


class EstudiantePdfView(ComprobanteBase):
    """Ficha del estudiante con sus matrículas y notas."""
    model = Estudiante
    template_pdf = "academico/pdf/estudiante_ficha.html"
    nombre_archivo = "estudiante"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["matriculas"] = (self.object.matriculas
                                  .select_related("seccion__curso", "seccion__periodo", "nota")
                                  .order_by("-seccion__periodo__fecha_inicio"))
        return contexto

    def obtener_universidad(self):
        return self.object.carrera.facultad.universidad


# =====================================================================
# 10. MATRÍCULA (con su Nota en la misma pantalla)
# =====================================================================
class MatriculaListView(ListadoBase):
    model = Matricula
    queryset = Matricula.objects.select_related("estudiante__carrera", "seccion__curso", "seccion__periodo",
                                                "seccion__profesor", "nota")
    filtro_form_class = forms.FiltroMatriculaForm
    campos_disponibles = [("estudiante__cedula", "Cédula"), ("estudiante", "Estudiante"),
                          ("seccion__curso__nombre", "Curso"), ("seccion__paralelo", "Paralelo"),
                          ("seccion__jornada", "Jornada"), ("seccion__periodo__nombre", "Periodo"),
                          ("seccion__profesor", "Profesor"), ("nota__n1", "Nota 1"), ("nota__n2", "Nota 2"),
                          ("nota__n3", "Nota 3"), ("nota__promedio", "Promedio"), ("nota__estado", "Estado"),
                          ("fecha", "Fecha")]
    campos_por_defecto = ["estudiante__cedula", "estudiante", "seccion__curso__nombre", "seccion__jornada",
                          "nota__promedio", "nota__estado"]
    titulo_reporte = "Reporte de matrículas y notas"
    nombre_archivo = "matriculas"

    def filtrar(self, queryset, datos):
        if datos.get("texto"):
            t = datos["texto"]
            queryset = queryset.filter(Q(estudiante__cedula__icontains=t) | Q(estudiante__apellidos__icontains=t))
        if datos.get("periodo"):
            queryset = queryset.filter(seccion__periodo=datos["periodo"])
        if datos.get("carrera"):
            queryset = queryset.filter(seccion__curso__carrera=datos["carrera"])
        if datos.get("curso"):
            queryset = queryset.filter(seccion__curso=datos["curso"])
        if datos.get("jornada"):
            queryset = queryset.filter(seccion__jornada=datos["jornada"])          # Matrícula → Sección
        if datos.get("estado"):
            queryset = queryset.filter(nota__estado=datos["estado"])               # Matrícula → Nota (1:1)
        if datos.get("promedio_desde") is not None:                                # 0 es un valor válido
            queryset = queryset.filter(nota__promedio__gte=datos["promedio_desde"])
        if datos.get("promedio_hasta") is not None:
            queryset = queryset.filter(nota__promedio__lte=datos["promedio_hasta"])
        return queryset


class MatriculaNotaMixin(CrudContextoMixin):
    """Formulario MAESTRO (Matrícula) + DETALLE 1:1 (Nota) en una sola pantalla."""
    model = Matricula
    form_class = forms.MatriculaForm
    template_name = "academico/matricula_form.html"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        if "nota_formset" not in contexto:
            contexto["nota_formset"] = forms.NotaFormSet(instance=self.object)
        return contexto

    def post(self, request, *args, **kwargs):
        self.object = self.get_object() if "pk" in self.kwargs else None      # editar: la existente; crear: ninguna
        form = self.get_form()
        self.nota_formset = forms.NotaFormSet(request.POST, instance=self.object)
        if form.is_valid() and self.nota_formset.is_valid():                   # se validan los DOS
            return self.form_valid(form)
        return self.form_invalid(form)

    def form_valid(self, form):
        with transaction.atomic():                                             # o se guardan los dos, o ninguno
            form.instance.user = self.request.user
            self.object = form.save()
            self.nota_formset.instance = self.object
            for nota in self.nota_formset.save(commit=False):
                nota.user = self.request.user
                nota.save()                                                    # save() calcula promedio y estado
        messages.success(self.request, "Matrícula guardada correctamente.")
        return HttpResponseRedirect(reverse(self.nombre_url("lista")))

    def form_invalid(self, form):
        return self.render_to_response(self.get_context_data(form=form, nota_formset=self.nota_formset))


class MatriculaCreateView(LoginRequiredMixin, MatriculaNotaMixin, CreateView):
    pass


class MatriculaUpdateView(LoginRequiredMixin, MatriculaNotaMixin, UpdateView):
    pass


class MatriculaDetailView(DetalleBase):
    model = Matricula
    detalle_campos = [("estudiante", "Estudiante"), ("estudiante__carrera", "Carrera"), ("seccion", "Sección"),
                      ("seccion__profesor", "Profesor"), ("fecha", "Fecha"), ("nota__n1", "Nota 1"),
                      ("nota__n2", "Nota 2"), ("nota__n3", "Nota 3"), ("nota__promedio", "Promedio"),
                      ("nota__estado", "Estado")]


class MatriculaDeleteView(EliminarBase):
    model = Matricula                                                          # la nota se borra sola (CASCADE)


class MatriculaPdfView(ComprobanteBase):
    model = Matricula
    template_pdf = "academico/pdf/matricula_comprobante.html"
    nombre_archivo = "matricula"

    def obtener_universidad(self):
        return self.object.estudiante.carrera.facultad.universidad
