# =====================================================================
# academico/forms.py · formularios de datos (ModelForm) y de filtros (Form)
# =====================================================================
from django import forms
from django.db.models import Q
from django.forms import inlineformset_factory

from core.forms import BootstrapFormMixin

from .models import (Carrera, Curso, Estudiante, Facultad, Jornada, EstadoNota, Matricula, Nota,
                     Periodo, Profesor, Seccion, Semestre, Universidad)

FECHA = dict(attrs={"type": "date"}, format="%Y-%m-%d")    # input type="date" necesita este formato


def validar_cedula(valor):
    """La cédula son exactamente 10 números."""
    if not (valor.isdigit() and len(valor) == 10):
        raise forms.ValidationError("La cédula debe tener exactamente 10 números.")
    return valor


# =====================================================================
# FORMULARIOS DE DATOS
# =====================================================================
class UniversidadForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Universidad
        fields = ["nombre", "siglas", "ciudad", "logo"]


class FacultadForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Facultad
        fields = ["universidad", "nombre", "decano"]


class CarreraForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Carrera
        fields = ["facultad", "codigo", "nombre", "duracion_semestres"]

    def clean_codigo(self):
        return self.cleaned_data["codigo"].strip().upper()      # SOF, no sof


class SemestreForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Semestre
        fields = ["numero", "nombre"]                            # el número (1 a 12) lo valida el modelo


class PeriodoForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Periodo
        fields = ["nombre", "fecha_inicio", "fecha_fin", "activo"]
        widgets = {"fecha_inicio": forms.DateInput(**FECHA), "fecha_fin": forms.DateInput(**FECHA)}


class CursoForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Curso
        fields = ["carrera", "semestre", "codigo", "nombre", "creditos"]

    def clean_codigo(self):
        return self.cleaned_data["codigo"].strip().upper()


class ProfesorForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Profesor
        fields = ["cedula", "nombres", "apellidos", "email", "titulo"]

    def clean_cedula(self):
        return validar_cedula(self.cleaned_data["cedula"])


class SeccionForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Seccion
        fields = ["curso", "periodo", "profesor", "paralelo", "jornada", "cupo"]

    def clean_paralelo(self):
        return self.cleaned_data["paralelo"].strip().upper()


class EstudianteForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Estudiante
        fields = ["cedula", "nombres", "apellidos", "email", "telefono", "fecha_nacimiento", "carrera", "foto"]
        widgets = {"fecha_nacimiento": forms.DateInput(**FECHA)}

    def clean_cedula(self):
        return validar_cedula(self.cleaned_data["cedula"])


# ---------------------------------------------------------------------
# Matrícula + Nota (maestro con su detalle 1:1 en una pantalla)
# ---------------------------------------------------------------------
class SeccionChoiceField(forms.ModelChoiceField):
    def label_from_instance(self, obj):                          # "SOF-101 A · Nocturna · 2026-1 (12/30)"
        return f"{obj} ({obj.inscritos}/{obj.cupo})"


class MatriculaForm(BootstrapFormMixin, forms.ModelForm):
    seccion = SeccionChoiceField(queryset=Seccion.objects.none(), label="Sección")

    class Meta:
        model = Matricula
        fields = ["estudiante", "seccion", "fecha"]
        widgets = {"fecha": forms.DateInput(**FECHA)}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        filtro = Q(periodo__activo=True)                         # solo secciones del periodo activo...
        if self.instance.seccion_id:
            filtro |= Q(pk=self.instance.seccion_id)             # ...y la actual al editar
        self.fields["seccion"].queryset = (
            Seccion.objects.filter(filtro).select_related("curso", "periodo").order_by("curso__codigo", "paralelo"))
        self.fields["estudiante"].queryset = Estudiante.objects.select_related("carrera")


class NotaForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Nota
        fields = ["n1", "n2", "n3"]                              # promedio y estado los calcula save()


NotaFormSet = inlineformset_factory(
    Matricula, Nota, form=NotaForm,
    fields=["n1", "n2", "n3"],
    extra=1, max_num=1,                                          # una sola nota por matrícula
    can_delete=False,
)


# =====================================================================
# FORMULARIOS DE FILTROS (todos los campos son opcionales)
# =====================================================================
def _combo(modelo, etiqueta, vacio="Todos"):
    return forms.ModelChoiceField(modelo.objects.all(), required=False, label=etiqueta, empty_label=vacio)


class FiltroUniversidadForm(BootstrapFormMixin, forms.Form):
    texto = forms.CharField(required=False, label="Nombre o siglas")
    ciudad = forms.CharField(required=False, label="Ciudad")


class FiltroFacultadForm(BootstrapFormMixin, forms.Form):
    texto = forms.CharField(required=False, label="Nombre o decano")
    universidad = _combo(Universidad, "Universidad")


class FiltroCarreraForm(BootstrapFormMixin, forms.Form):
    texto = forms.CharField(required=False, label="Código o nombre")
    universidad = _combo(Universidad, "Universidad")
    facultad = _combo(Facultad, "Facultad")


class FiltroSemestreForm(BootstrapFormMixin, forms.Form):
    texto = forms.CharField(required=False, label="Número o nombre")


class FiltroPeriodoForm(BootstrapFormMixin, forms.Form):
    activo = forms.ChoiceField(required=False, label="Estado",
                               choices=[("", "Todos"), ("1", "Activo"), ("0", "No activo")])
    anio = forms.IntegerField(required=False, label="Año", min_value=2000, max_value=2100)


class FiltroCursoForm(BootstrapFormMixin, forms.Form):
    texto = forms.CharField(required=False, label="Código o nombre")
    carrera = _combo(Carrera, "Carrera")
    semestre = _combo(Semestre, "Semestre")


class FiltroProfesorForm(BootstrapFormMixin, forms.Form):
    texto = forms.CharField(required=False, label="Cédula o apellidos")
    periodo = _combo(Periodo, "Periodo")


class FiltroSeccionForm(BootstrapFormMixin, forms.Form):
    periodo = _combo(Periodo, "Periodo")
    carrera = _combo(Carrera, "Carrera")
    jornada = forms.ChoiceField(required=False, label="Jornada", choices=[("", "Todas")] + Jornada.choices)
    profesor = _combo(Profesor, "Profesor")


class FiltroEstudianteForm(BootstrapFormMixin, forms.Form):
    texto = forms.CharField(required=False, label="Nombre o cédula")
    carrera = _combo(Carrera, "Carrera")
    facultad = _combo(Facultad, "Facultad")
    nacido_desde = forms.DateField(required=False, label="Nacido desde", widget=forms.DateInput(**FECHA))
    nacido_hasta = forms.DateField(required=False, label="Nacido hasta", widget=forms.DateInput(**FECHA))


class FiltroMatriculaForm(BootstrapFormMixin, forms.Form):
    texto = forms.CharField(required=False, label="Cédula o apellido")
    periodo = _combo(Periodo, "Periodo")
    carrera = _combo(Carrera, "Carrera")
    curso = _combo(Curso, "Curso")
    jornada = forms.ChoiceField(required=False, label="Jornada", choices=[("", "Todas")] + Jornada.choices)
    estado = forms.ChoiceField(required=False, label="Estado", choices=[("", "Todos")] + EstadoNota.choices)
    promedio_desde = forms.DecimalField(required=False, label="Promedio desde", min_value=0, max_value=100)
    promedio_hasta = forms.DecimalField(required=False, label="Promedio hasta", min_value=0, max_value=100)
