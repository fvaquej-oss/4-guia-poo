# =====================================================================
# academico/tests.py · pruebas automáticas.  Ejecutar:  python manage.py test
# =====================================================================
from decimal import Decimal
from io import BytesIO

from django.contrib.auth.models import User
from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse
from openpyxl import load_workbook

from .models import Carrera, Estudiante, Matricula, Nota, Periodo, Seccion, Universidad


class BaseTest(TestCase):
    @classmethod
    def setUpTestData(cls):
        call_command("poblar_datos", verbosity=0)                  # los mismos datos de prueba de la guía
        cls.usuario = User.objects.create_user("profe", password="clave12345")

    def setUp(self):
        self.client.force_login(self.usuario)


class AccesoTests(BaseTest):
    def test_sin_sesion_va_al_login(self):
        self.client.logout()
        r = self.client.get(reverse("academico:inicio"))
        self.assertRedirects(r, "/login/?next=/academico/")

    def test_inicio_muestra_tarjetas(self):
        r = self.client.get(reverse("academico:inicio"))
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.context["total_estudiantes"], 15)
        self.assertEqual(r.context["total_matriculas"], 25)


class ModelosTests(BaseTest):
    def test_nota_calcula_promedio_y_estado(self):
        m = Matricula.objects.filter(nota__isnull=True).first()
        nota = Nota.objects.create(matricula=m, n1=Decimal("80"), n2=Decimal("65"), n3=Decimal("66"))
        self.assertEqual(nota.promedio, Decimal("70.33"))
        self.assertEqual(nota.estado, "aprobado")
        nota.n2 = Decimal("40")
        nota.save()
        self.assertEqual(nota.estado, "reprobado")

    def test_matricula_rechaza_otra_carrera(self):
        red = Estudiante.objects.filter(carrera__codigo="RED").first()
        seccion = Seccion.objects.filter(curso__codigo="SOF-101").first()
        from django.core.exceptions import ValidationError
        with self.assertRaises(ValidationError):
            Matricula(estudiante=red, seccion=seccion).full_clean()

    def test_matricula_rechaza_sin_cupo(self):
        seccion = Seccion.objects.get(curso__codigo="RED-101")
        seccion.cupo = 5                                           # ya tiene 5 matriculados
        seccion.save()
        nuevo = Estudiante.objects.create(cedula="0955555555", nombres="Nuevo", apellidos="Alumno",
                                          carrera=Carrera.objects.get(codigo="RED"))
        from django.core.exceptions import ValidationError
        with self.assertRaises(ValidationError):
            Matricula(estudiante=nuevo, seccion=seccion).full_clean()


class CrudEstudianteTests(BaseTest):
    def test_lista_pagina_y_conserva_filtros(self):
        r = self.client.get(reverse("academico:estudiante_lista"))
        self.assertEqual(len(r.context["object_list"]), 10)         # paginate_by = 10
        r = self.client.get(reverse("academico:estudiante_lista"), {"carrera": Carrera.objects.get(codigo="SOF").pk})
        self.assertEqual(r.context["paginator"].count, 10)
        self.assertContains(r, "carrera=")

    def test_filtros_combinados(self):
        sof = Carrera.objects.get(codigo="SOF").pk
        r = self.client.get(reverse("academico:estudiante_lista"), {"carrera": sof, "texto": "Pérez"})
        self.assertEqual(r.context["paginator"].count, 1)

    def test_columnas_solo_las_permitidas(self):
        r = self.client.get(reverse("academico:estudiante_lista"),
                            {"campos": ["cedula", "user__password"]})
        self.assertEqual(r.context["encabezados"], ["Cédula"])      # la ruta peligrosa se ignora

    def test_crear_con_cedula_invalida(self):
        datos = {"cedula": "123", "nombres": "A", "apellidos": "B", "carrera": Carrera.objects.first().pk}
        r = self.client.post(reverse("academico:estudiante_crear"), datos)
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "exactamente 10 números")

    def test_crear_editar_eliminar(self):
        carrera = Carrera.objects.get(codigo="SOF")
        datos = {"cedula": "0944444444", "nombres": "Rosa", "apellidos": "Nuevo", "carrera": carrera.pk}
        r = self.client.post(reverse("academico:estudiante_crear"), datos)
        self.assertRedirects(r, reverse("academico:estudiante_lista"))
        est = Estudiante.objects.get(cedula="0944444444")
        self.assertEqual(est.user, self.usuario)                    # UsuarioRegistroMixin
        datos["nombres"] = "Rosita"
        self.client.post(reverse("academico:estudiante_editar", args=[est.pk]), datos)
        est.refresh_from_db()
        self.assertEqual(est.nombres, "Rosita")
        self.client.post(reverse("academico:estudiante_eliminar", args=[est.pk]))
        self.assertFalse(Estudiante.objects.filter(pk=est.pk).exists())

    def test_no_elimina_con_matriculas(self):
        est = Matricula.objects.first().estudiante
        r = self.client.post(reverse("academico:estudiante_eliminar", args=[est.pk]), follow=True)
        self.assertTrue(Estudiante.objects.filter(pk=est.pk).exists())
        self.assertContains(r, "No se puede eliminar")


class ExportarTests(BaseTest):
    def test_excel_respeta_filtros_y_columnas_sin_paginar(self):
        sof = Carrera.objects.get(codigo="SOF").pk
        r = self.client.get(reverse("academico:estudiante_lista"),
                            {"carrera": sof, "campos": ["cedula", "apellidos", "carrera__nombre"], "exportar": "excel"})
        self.assertIn("spreadsheetml", r["Content-Type"])
        hoja = load_workbook(BytesIO(r.content)).active
        self.assertEqual([c.value for c in hoja[3]], ["Cédula", "Apellidos", "Carrera"])
        self.assertEqual(hoja.max_row, 3 + 10)                      # 10 de Software, aunque paginate_by = 10 y hay 15

    def test_excel_trae_todas_las_filas(self):
        r = self.client.get(reverse("academico:estudiante_lista"), {"exportar": "excel"})
        self.assertEqual(load_workbook(BytesIO(r.content)).active.max_row, 3 + 15)

    def test_pdf_listado(self):
        r = self.client.get(reverse("academico:estudiante_lista"), {"exportar": "pdf"})
        self.assertTrue(r.content.startswith(b"%PDF"))

    def test_matriculas_filtro_jornada_estado(self):
        r = self.client.get(reverse("academico:matricula_lista"), {"jornada": "nocturna", "estado": "reprobado"})
        esperado = Matricula.objects.filter(seccion__jornada="nocturna", nota__estado="reprobado").count()
        self.assertEqual(r.context["paginator"].count, esperado)

    def test_matriculas_rango_promedio(self):
        r = self.client.get(reverse("academico:matricula_lista"), {"promedio_desde": "70", "promedio_hasta": "100"})
        self.assertEqual(r.context["paginator"].count, Nota.objects.filter(promedio__gte=70).count())

    def test_matriculas_sin_nota_no_rompe_la_tabla(self):
        r = self.client.get(reverse("academico:matricula_lista"), {"campos": ["nota__promedio"], "page": 3})
        self.assertEqual(r.status_code, 200)

    def test_excel_de_matriculas(self):
        r = self.client.get(reverse("academico:matricula_lista"), {"exportar": "excel", "campos": ["nota__promedio", "nota__estado"]})
        self.assertEqual(r.status_code, 200)


class MatriculaNotaTests(BaseTest):
    def datos(self, estudiante, seccion, n1="80", n2="65", n3="66"):
        return {"estudiante": estudiante.pk, "seccion": seccion.pk, "fecha": "2026-03-25",
                "nota-TOTAL_FORMS": "1", "nota-INITIAL_FORMS": "0", "nota-MIN_NUM_FORMS": "0", "nota-MAX_NUM_FORMS": "1",
                "nota-0-n1": n1, "nota-0-n2": n2, "nota-0-n3": n3}

    def test_crear_matricula_con_nota(self):
        est = Estudiante.objects.create(cedula="0966666666", nombres="Nora", apellidos="Prueba",
                                        carrera=Carrera.objects.get(codigo="SOF"))
        seccion = Seccion.objects.get(curso__codigo="SOF-101", paralelo="A")
        r = self.client.post(reverse("academico:matricula_crear"), self.datos(est, seccion))
        self.assertRedirects(r, reverse("academico:matricula_lista"))
        m = Matricula.objects.get(estudiante=est, seccion=seccion)
        self.assertEqual(m.nota.promedio, Decimal("70.33"))
        self.assertEqual(m.nota.estado, "aprobado")
        self.assertEqual(m.nota.user, self.usuario)

    def test_editar_nota_cambia_estado(self):
        m = Matricula.objects.filter(nota__estado="aprobado").first()
        nota = m.nota
        datos = self.datos(m.estudiante, m.seccion, n1="10", n2="10", n3="10")
        datos.update({"nota-INITIAL_FORMS": "1", "nota-0-id": nota.pk, "nota-0-matricula": m.pk})
        self.client.post(reverse("academico:matricula_editar", args=[m.pk]), datos)
        nota.refresh_from_db()
        self.assertEqual(nota.estado, "reprobado")

    def test_error_de_carrera_sale_en_el_formulario(self):
        red = Estudiante.objects.filter(carrera__codigo="RED").first()
        seccion = Seccion.objects.get(curso__codigo="SOF-101", paralelo="A")
        r = self.client.post(reverse("academico:matricula_crear"), self.datos(red, seccion))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "no pertenece a la carrera")

    def test_error_de_cupo(self):
        seccion = Seccion.objects.get(curso__codigo="SOF-101", paralelo="B")
        seccion.cupo = seccion.inscritos
        seccion.save()
        est = Estudiante.objects.create(cedula="0977777777", nombres="Sin", apellidos="Cupo",
                                        carrera=Carrera.objects.get(codigo="SOF"))
        r = self.client.post(reverse("academico:matricula_crear"), self.datos(est, seccion))
        self.assertContains(r, "no tiene cupo")

    def test_eliminar_matricula_borra_la_nota(self):
        m = Matricula.objects.filter(nota__isnull=False).first()
        nota_pk = m.nota.pk
        self.client.post(reverse("academico:matricula_eliminar", args=[m.pk]))
        self.assertFalse(Nota.objects.filter(pk=nota_pk).exists())


class PdfComprobantesTests(BaseTest):
    def test_todos_los_comprobantes_son_pdf(self):
        modelos = ["universidad", "facultad", "carrera", "semestre", "periodo", "curso", "profesor",
                   "seccion", "estudiante", "matricula"]
        from django.apps import apps
        for nombre in modelos:
            obj = apps.get_model("academico", nombre).objects.first()
            r = self.client.get(reverse(f"academico:{nombre}_pdf", args=[obj.pk]))
            self.assertEqual(r.status_code, 200, nombre)
            self.assertTrue(r.content.startswith(b"%PDF"), nombre)

    def test_comprobante_de_matricula_sin_nota(self):
        m = Matricula.objects.filter(nota__isnull=True).first()
        r = self.client.get(reverse("academico:matricula_pdf", args=[m.pk]))
        self.assertTrue(r.content.startswith(b"%PDF"))


class TodosLosCrudTests(BaseTest):
    """Cada uno de los 10 CRUD: lista, detalle, formulario de crear/editar, eliminar, Excel y PDF."""
    MODELOS = ["universidad", "facultad", "carrera", "semestre", "periodo", "curso", "profesor",
               "seccion", "estudiante", "matricula"]

    def test_paginas_responden_200(self):
        from django.apps import apps
        for nombre in self.MODELOS:
            obj = apps.get_model("academico", nombre).objects.first()
            for accion, args in [("lista", []), ("crear", []), ("detalle", [obj.pk]),
                                 ("editar", [obj.pk]), ("eliminar", [obj.pk])]:
                r = self.client.get(reverse(f"academico:{nombre}_{accion}", args=args))
                self.assertEqual(r.status_code, 200, f"{nombre}_{accion}")
            for formato in ("excel", "pdf"):
                r = self.client.get(reverse(f"academico:{nombre}_lista"), {"exportar": formato})
                self.assertEqual(r.status_code, 200, f"{nombre} {formato}")

    def test_solo_un_periodo_activo(self):
        datos = {"nombre": "2026-2", "fecha_inicio": "2026-09-01", "fecha_fin": "2027-01-31", "activo": "on"}
        self.client.post(reverse("academico:periodo_crear"), datos)
        self.assertEqual(Periodo.objects.filter(activo=True).count(), 1)
        self.assertTrue(Periodo.objects.get(nombre="2026-2").activo)

    def test_periodo_fecha_fin_invalida(self):
        datos = {"nombre": "2027-1", "fecha_inicio": "2027-05-01", "fecha_fin": "2027-04-01"}
        r = self.client.post(reverse("academico:periodo_crear"), datos)
        self.assertContains(r, "posterior a la de inicio")

    def test_carrera_codigo_en_mayusculas(self):
        from .models import Facultad
        self.client.post(reverse("academico:carrera_crear"),
                         {"facultad": Facultad.objects.first().pk, "codigo": "mat", "nombre": "Matemática", "duracion_semestres": 8})
        self.assertTrue(Carrera.objects.filter(codigo="MAT").exists())

    def test_facultad_nombre_unico_por_universidad(self):
        from .models import Facultad
        f = Facultad.objects.first()
        r = self.client.post(reverse("academico:facultad_crear"), {"universidad": f.universidad.pk, "nombre": f.nombre})
        self.assertEqual(r.status_code, 200)                       # vuelve al formulario con el error

    def test_universidad_con_facultades_no_se_elimina(self):
        u = Universidad.objects.get(siglas="UG")
        self.client.post(reverse("academico:universidad_eliminar", args=[u.pk]))
        self.assertTrue(Universidad.objects.filter(pk=u.pk).exists())

    def test_profesor_filtro_por_periodo_sin_repetidos(self):
        periodo = Periodo.objects.get(activo=True)
        r = self.client.get(reverse("academico:profesor_lista"), {"periodo": periodo.pk})
        self.assertEqual(r.context["paginator"].count, 3)
