# Bitácora de prompts

> Criterio de evaluación de la guía (1 punto): por cada prompt usado, anota **qué falló** y **cómo lo corregiste**.
> Esta tabla ya trae los prompts que cubre el proyecto; completa las dos últimas columnas con TU experiencia.

| N.º | Prompt (Guía 4) | Qué se pidió | Qué falló | Cómo lo corregí |
|---|---|---|---|---|
| 0 | Contexto del proyecto | Reglas del proyecto (solo vistas de clase, LoginRequiredMixin primero, código comentado) | | |
| 1 | Crear los modelos | `ModeloBase` y los 11 modelos con sus reglas (cupo, carrera, aprobación 70) | | |
| 2 | Admin y datos de prueba | `BaseAdmin`, Nota inline en Matrícula y comando `poblar_datos` | | |
| 3 | Base del proyecto | settings, urls, `InicioView`, `base.html`, login | | |
| 4 | CRUD básico de Estudiante | Formulario, 5 vistas, URLs y templates | | |
| 5 | Componente de filtros + columnas | `valor_campo`, `FiltroCamposMixin`, `_filtros.html` | | |
| 6 | Exportar a Excel | `exportar_excel`, `ExportarMixin` | | |
| 7 | Listado en PDF | `render_pdf`, `listado.html`, filtros aplicados | | |
| 8 | Comprobante PDF | `ComprobantePdfMixin`, ficha del estudiante | | |
| 9 | CRUD Matrícula + Nota | `inlineformset_factory`, `MatriculaNotaMixin` | | |
| 10 | Componentes en Matrículas | Filtros por periodo, jornada, estado y promedio | | |
| 11 | Comprobante de matrícula | PDF con estado en color y firmas | | |
| Plantilla | Replicar un CRUD (×8) | Universidad, Facultad, Carrera, Semestre, Periodo, Curso, Profesor, Sección | | |

## Notas de la bitácora

(Escribe aquí los errores reales que te salieron y cómo los resolviste: copia el mensaje de error y tu corrección.)
