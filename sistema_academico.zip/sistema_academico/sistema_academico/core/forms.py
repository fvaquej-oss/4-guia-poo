# =====================================================================
# core/forms.py · le pone las clases de Bootstrap a TODOS los campos de un formulario
# =====================================================================
from django import forms


class BootstrapFormMixin:
    """Mezclar con ModelForm o Form: asigna form-control / form-select / form-check-input."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for campo in self.fields.values():
            widget = campo.widget
            if isinstance(widget, forms.CheckboxInput):
                clase = "form-check-input"
            elif isinstance(widget, (forms.Select, forms.SelectMultiple)):
                clase = "form-select"
            elif isinstance(widget, forms.FileInput):
                clase = "form-control"
            else:
                clase = "form-control"
            widget.attrs["class"] = f'{widget.attrs.get("class", "")} {clase}'.strip()
