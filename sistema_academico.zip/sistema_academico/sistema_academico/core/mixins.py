# =====================================================================
# core/mixins.py · COMPONENTES reutilizables. Ninguno menciona un modelo concreto:
# cada CRUD solo los CONFIGURA con atributos.
# =====================================================================
from django.contrib import messages
from django.db.models import ProtectedError
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.utils import timezone

from .utils import exportar_excel, render_pdf, valor_campo


class UsuarioRegistroMixin:
    """Al guardar, anota quién registró o modificó el registro (ModeloBase.user)."""

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)


class CrudContextoMixin:
    """Da a los templates genéricos los títulos y los nombres de URL del modelo.

    Las URLs siguen el patrón <modelo>_lista, _crear, _detalle, _editar, _eliminar y _pdf.
    El namespace (app_name) se toma de la URL actual: así core no depende de ninguna app.
    """

    def nombre_url(self, accion):
        return f"{self.request.resolver_match.app_name}:{self.model._meta.model_name}_{accion}"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        acciones = ("lista", "crear", "detalle", "editar", "eliminar", "pdf")
        contexto["urls"] = {a: self.nombre_url(a) for a in acciones}
        contexto["nombre_singular"] = self.model._meta.verbose_name
        contexto["nombre_plural"] = self.model._meta.verbose_name_plural
        return contexto


class EliminarProtegidoMixin:
    """Para DeleteView: si el registro tiene hijos (PROTECT) muestra un mensaje en vez de un error 500."""
    mensaje_protegido = "No se puede eliminar: tiene registros relacionados."

    def form_valid(self, form):
        try:
            respuesta = super().form_valid(form)
        except ProtectedError:
            messages.error(self.request, self.mensaje_protegido)
            return HttpResponseRedirect(reverse(self.nombre_url("detalle"), args=[self.object.pk]))
        messages.success(self.request, f"{self.model._meta.verbose_name} eliminado correctamente.")
        return respuesta


# ---------------------------------------------------------------------
# COMPONENTE 1 · filtros + selección de columnas
# ---------------------------------------------------------------------
class FiltroCamposMixin:
    """Filtros + selección de columnas. Se combina con ListView."""
    filtro_form_class = None          # formulario de filtros (Form normal, todos los campos opcionales)
    campos_disponibles = []           # [("ruta__del__campo", "Título"), ...]
    campos_por_defecto = []           # rutas que se marcan si el usuario no elige ninguna

    def filtrar(self, queryset, datos):
        """Cada vista lo sobrescribe: recibe cleaned_data y devuelve el queryset filtrado."""
        return queryset

    def get_queryset(self):
        queryset = super().get_queryset()
        self.filtro_form = self.filtro_form_class(self.request.GET or None) if self.filtro_form_class else None
        if self.filtro_form is not None and self.filtro_form.is_valid():
            queryset = self.filtrar(queryset, self.filtro_form.cleaned_data)
        return queryset

    def get_campos_seleccionados(self):
        titulos = dict(self.campos_disponibles)
        elegidos = [c for c in self.request.GET.getlist("campos") if c in titulos]   # SOLO rutas permitidas
        elegidos = elegidos or self.campos_por_defecto or list(titulos)
        return [(c, titulos[c]) for c in elegidos]

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        campos = self.get_campos_seleccionados()
        contexto["filtro_form"] = self.filtro_form
        contexto["campos_disponibles"] = self.campos_disponibles
        contexto["campos_seleccionados"] = [c for c, _ in campos]
        contexto["encabezados"] = [t for _, t in campos]
        contexto["filas"] = [(obj, [valor_campo(obj, c) for c, _ in campos]) for obj in contexto["object_list"]]
        consulta = self.request.GET.copy()                           # la consulta actual SIN page ni exportar
        consulta.pop("page", None)
        consulta.pop("exportar", None)
        contexto["consulta"] = consulta.urlencode()
        return contexto


# ---------------------------------------------------------------------
# COMPONENTE 2 · exportar el listado a Excel y PDF
# ---------------------------------------------------------------------
class ExportarMixin(FiltroCamposMixin):
    """Agrega ?exportar=excel y ?exportar=pdf al listado, con los MISMOS filtros y columnas."""
    titulo_reporte = "Listado"
    nombre_archivo = "listado"
    template_pdf = "core/pdf/listado.html"

    def filtros_aplicados(self):
        """["Carrera: Software", ...] con las etiquetas del formulario de filtros."""
        if self.filtro_form is None or not self.filtro_form.is_valid():
            return []
        textos = []
        for nombre, campo in self.filtro_form.fields.items():
            valor = self.filtro_form.cleaned_data.get(nombre)
            if valor in (None, "", []):
                continue
            opciones = dict(getattr(campo, "choices", [])) if not hasattr(campo, "queryset") else {}
            texto = opciones.get(valor, valor)
            textos.append(f"{campo.label or nombre.capitalize()}: {texto}")
        return textos

    def get(self, request, *args, **kwargs):
        formato = request.GET.get("exportar")
        if formato not in ("excel", "pdf"):
            return super().get(request, *args, **kwargs)             # pantalla normal
        queryset = self.get_queryset()                              # ← mismos filtros, SIN paginar
        campos = self.get_campos_seleccionados()
        encabezados = [t for _, t in campos]
        filas = [[valor_campo(obj, c) for c, _ in campos] for obj in queryset]
        if formato == "excel":
            return exportar_excel(self.titulo_reporte, encabezados, filas, self.nombre_archivo)
        contexto = {
            "titulo": self.titulo_reporte,
            "fecha": timezone.localtime(),
            "usuario": request.user,
            "total": len(filas),
            "filtros": self.filtros_aplicados(),
            "encabezados": encabezados,
            "filas": filas,
        }
        return render_pdf(self.template_pdf, contexto, self.nombre_archivo)


# ---------------------------------------------------------------------
# COMPONENTE 3 · comprobante PDF de UN registro
# ---------------------------------------------------------------------
class ComprobantePdfMixin:
    """Convierte una DetailView en un PDF (comprobante de un registro)."""
    template_pdf = None
    nombre_archivo = "comprobante"

    def obtener_universidad(self):
        """Cada vista dice de qué universidad es el comprobante (para el logo). None = sin logo."""
        return None

    def render_to_response(self, context, **response_kwargs):
        context["fecha"] = timezone.localtime()
        context["usuario"] = self.request.user
        context["universidad"] = self.obtener_universidad()
        return render_pdf(self.template_pdf, context, f"{self.nombre_archivo}-{self.object.pk}")
