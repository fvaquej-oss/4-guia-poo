# =====================================================================
# core/views.py · vistas BASE (todas basadas en clases) que reutiliza cada CRUD.
# LoginRequiredMixin siempre es la PRIMERA clase de la herencia.
# =====================================================================
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.messages.views import SuccessMessageMixin
from django.urls import reverse
from django.views.generic import CreateView, DeleteView, DetailView, ListView, UpdateView

from .mixins import (ComprobantePdfMixin, CrudContextoMixin, EliminarProtegidoMixin,
                     ExportarMixin, UsuarioRegistroMixin)
from .utils import valor_campo


class ListadoBase(LoginRequiredMixin, CrudContextoMixin, ExportarMixin, ListView):
    """Listado paginado con filtros, columnas, Excel y PDF."""
    template_name = "core/crud_lista.html"
    paginate_by = 10


class _GuardarBase(LoginRequiredMixin, UsuarioRegistroMixin, CrudContextoMixin, SuccessMessageMixin):
    template_name = "core/crud_form.html"

    def get_success_url(self):
        return reverse(self.nombre_url("lista"))

    def get_success_message(self, cleaned_data):
        return f"{self.model._meta.verbose_name} guardado correctamente."


class CrearBase(_GuardarBase, CreateView):
    pass


class EditarBase(_GuardarBase, UpdateView):
    pass


class DetalleBase(LoginRequiredMixin, CrudContextoMixin, DetailView):
    """Detalle genérico: muestra detalle_campos y, debajo, tablas de registros relacionados.

    detalle_campos = [("ruta", "Título"), ...]
    relaciones = [("Título", "related_name", [("ruta", "Título"), ...]), ...]
    """
    template_name = "core/crud_detalle.html"
    detalle_campos = []
    relaciones = []

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["datos"] = [(titulo, valor_campo(self.object, ruta)) for ruta, titulo in self.detalle_campos]
        tablas = []
        for titulo, accesor, columnas in self.relaciones:
            objetos = getattr(self.object, accesor).all()
            tablas.append({
                "titulo": titulo,
                "encabezados": [t for _, t in columnas],
                "filas": [(o, [valor_campo(o, r) for r, _ in columnas]) for o in objetos],
            })
        contexto["tablas"] = tablas
        return contexto


class EliminarBase(LoginRequiredMixin, CrudContextoMixin, EliminarProtegidoMixin, DeleteView):
    template_name = "core/crud_eliminar.html"

    def get_success_url(self):
        return reverse(self.nombre_url("lista"))


class ComprobanteBase(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    """Detalle que responde con un PDF (el comprobante del registro)."""
