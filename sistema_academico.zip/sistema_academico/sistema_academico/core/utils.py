# =====================================================================
# core/utils.py · funciones reutilizables (no conocen ningún modelo del negocio)
# =====================================================================
from decimal import Decimal
from io import BytesIO

from django.conf import settings
from django.http import HttpResponse
from django.template.loader import render_to_string
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from xhtml2pdf import pisa


def valor_campo(objeto, ruta):
    """Lee un dato siguiendo una ruta con "__": valor_campo(est, "carrera__facultad__nombre").

    - Si el campo tiene choices devuelve el texto (get_X_display).
    - Si algo no existe en el camino (ej. una matrícula sin nota) devuelve "".
    - También lee @property y métodos sin parámetros.
    """
    for parte in ruta.split("__"):
        if objeto is None:
            return ""
        display = getattr(objeto, f"get_{parte}_display", None)    # campo con choices → su texto
        objeto = display() if display else getattr(objeto, parte, "")
        if callable(objeto):                                        # métodos sin parámetros
            objeto = objeto()
    if objeto is None:
        return ""
    if isinstance(objeto, bool):                                    # True/False → Sí/No
        return "Sí" if objeto else "No"
    return objeto


# ---------------------------------------------------------------------
# EXCEL
# ---------------------------------------------------------------------
def exportar_excel(titulo, encabezados, filas, nombre_archivo):
    """Genera un .xlsx con título, encabezados verdes y los datos. Devuelve el HttpResponse."""
    libro = Workbook()
    hoja = libro.active
    hoja.title = titulo[:31]                                        # Excel: máximo 31 caracteres
    hoja.append([titulo])
    hoja["A1"].font = Font(bold=True, size=14)
    hoja.append([])
    hoja.append(list(encabezados))
    for celda in hoja[3]:                                           # fila 3 = encabezados
        celda.font = Font(bold=True, color="FFFFFF")
        celda.fill = PatternFill("solid", fgColor="0C4B33")
    for fila in filas:
        hoja.append([_para_excel(v) for v in fila])
    for columna in hoja.columns:                                    # ancho automático (máximo 50)
        largo = max(len(str(c.value or "")) for c in columna)
        hoja.column_dimensions[columna[0].column_letter].width = min(largo + 2, 50)
    hoja.freeze_panes = "A4"                                        # encabezados fijos al bajar
    respuesta = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    respuesta["Content-Disposition"] = f'attachment; filename="{nombre_archivo}.xlsx"'
    libro.save(respuesta)                                           # el libro se escribe DENTRO de la respuesta
    return respuesta


def _para_excel(valor):
    if isinstance(valor, Decimal):
        return float(valor)
    if isinstance(valor, (int, float)):
        return valor
    return str(valor)


# ---------------------------------------------------------------------
# PDF
# ---------------------------------------------------------------------
def enlazar_archivos(uri, rel):
    """xhtml2pdf necesita rutas del DISCO para las imágenes: /media/x.png → C:/.../media/x.png"""
    if uri.startswith(settings.MEDIA_URL):
        return str(settings.MEDIA_ROOT / uri.replace(settings.MEDIA_URL, "", 1))
    if uri.startswith("/" + settings.MEDIA_URL):
        return str(settings.MEDIA_ROOT / uri.replace("/" + settings.MEDIA_URL, "", 1))
    if uri.startswith(settings.STATIC_URL):
        return str(settings.BASE_DIR / "static" / uri.replace(settings.STATIC_URL, "", 1))
    if uri.startswith("/" + settings.STATIC_URL.lstrip("/")):
        return str(settings.BASE_DIR / "static" / uri.replace("/" + settings.STATIC_URL.lstrip("/"), "", 1))
    return uri


def render_pdf(template, contexto, nombre_archivo, descargar=False):
    """Template de Django + datos → HTML → PDF. inline = se abre en el navegador."""
    html = render_to_string(template, contexto)                     # 1. template + datos → HTML
    buffer = BytesIO()
    resultado = pisa.CreatePDF(html, dest=buffer, link_callback=enlazar_archivos)   # 2. HTML → PDF
    if resultado.err:
        return HttpResponse("Error al generar el PDF", status=500)
    respuesta = HttpResponse(buffer.getvalue(), content_type="application/pdf")
    modo = "attachment" if descargar else "inline"
    respuesta["Content-Disposition"] = f'{modo}; filename="{nombre_archivo}.pdf"'
    return respuesta
