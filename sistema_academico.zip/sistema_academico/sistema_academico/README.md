# Sistema Académico (Django · vistas basadas en clases)

Proyecto de la **Guía 4 · Sistema Académico con prompts**: 11 modelos, 10 CRUD con vistas basadas en clases
y tres componentes reutilizables en `core` (filtros con selección de columnas, exportar a Excel/PDF y comprobante PDF).

## Cómo ejecutarlo

```bash
python -m venv venv
venv\Scripts\activate              # Mac/Linux: source venv/bin/activate
pip install -r requirements.txt
python manage.py runserver
```

Abre http://127.0.0.1:8000/ e inicia sesión con **admin / admin12345** (cámbiala si lo vas a publicar).
El archivo `db.sqlite3` ya trae datos de prueba. Si quieres empezar de cero:

```bash
del db.sqlite3                      # Mac/Linux: rm db.sqlite3
python manage.py migrate
python manage.py createsuperuser
python manage.py poblar_datos       # 2 universidades, 15 estudiantes, 25 matrículas, notas variadas...
```

`python manage.py poblar_datos` se puede ejecutar varias veces: no duplica datos.

## Estructura

```
core/                      componentes reutilizables (no conocen el negocio)
  models.py                ModeloBase (user, fecha_creacion, fecha_modificacion)
  mixins.py                UsuarioRegistroMixin, FiltroCamposMixin, ExportarMixin, ComprobantePdfMixin
  views.py                 vistas base: ListadoBase, CrearBase, EditarBase, DetalleBase, EliminarBase, ComprobanteBase
  utils.py                 valor_campo, exportar_excel, render_pdf
  templates/core/          _filtros.html, crud_*.html y pdf/ (listado.html, base_pdf.html)
academico/                 el negocio
  models.py                11 modelos (Universidad ... Matricula, Nota)
  forms.py                 formularios de datos y de filtros, NotaFormSet
  views.py                 10 CRUD: cada uno solo CONFIGURA los componentes de core
  urls.py                  rutas <modelo>_lista / _crear / _detalle / _editar / _eliminar / _pdf
  templates/academico/     inicio, matricula_form, estudiante_detalle y pdf/ (10 comprobantes)
  management/commands/poblar_datos.py
  tests.py                 32 pruebas:  python manage.py test
templates/                 base.html (menú Bootstrap 5) y login
```

## Los 10 CRUD

| Menú | CRUD | Comprobante PDF |
|---|---|---|
| Estructura | Universidades, Facultades, Carreras | Ficha de universidad · Ficha de facultad · Malla curricular |
| Catálogo | Semestres, Periodos, Cursos | Cursos del semestre · Resumen del periodo · Ficha del curso |
| Personas | Profesores, Estudiantes | Carga académica · Ficha del estudiante |
| Académico | Secciones, Matrículas (con su nota) | Acta de calificaciones · Comprobante de matrícula |

Todos tienen: crear, editar, ver y eliminar (con mensaje si hay registros relacionados), filtros combinables,
selección de columnas, exportar a Excel y PDF con **los mismos filtros y columnas** de la pantalla, y comprobante PDF.

## Reglas del negocio (viven en los modelos)

- Se aprueba con promedio **≥ 70** (`Nota.save()` calcula promedio y estado).
- Solo se matricula en cursos de la carrera del estudiante y mientras haya cupo (`Matricula.clean()`).
- Solo un periodo activo a la vez (al activar uno, se desactivan los demás).
