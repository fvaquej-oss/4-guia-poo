"""URLs del proyecto: admin, login/logout, la app academico y los archivos media."""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import include, path
from django.views.generic import RedirectView

urlpatterns = [
    path("admin/", admin.site.urls),
    path("login/", auth_views.LoginView.as_view(), name="login"),          # busca registration/login.html
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),       # solo acepta POST
    path("academico/", include("academico.urls")),
    path("", RedirectView.as_view(pattern_name="academico:inicio", permanent=False)),
]

if settings.DEBUG:                                                         # servir logos y fotos al desarrollar
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
